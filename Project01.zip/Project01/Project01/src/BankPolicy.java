public class BankPolicy {
    static protected double interestRate = 0.05;
}
